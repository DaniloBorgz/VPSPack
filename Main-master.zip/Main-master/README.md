# Main
Projeto: R3V1V3R VPS
Faz parte do R3V1V3R 1NT3RN3T L1VR3
BY @judiba

Novos projetos ficam aqui neste local...

Configurar VPS com diversos recursos.
Os "scripts" foram revisados e adaptados para não ter nenhum código malicioso ou modificações que interfiram no funcionamento da VPS. Os scripts foram retirados em parte ou na sua totalidade de scripts conhecidos como do vpsmanager do Phreaker56 e do PackSSH.

Obs.:

1> Não me resposabilizo por problemas decorrentes do uso deste script.
2> Não dou suporte ao seu funcionamento.
3> Caso queira fazer alguma modificação e ou alteração informe para que possa ser verificado e continuar contribuino com o projeto.
